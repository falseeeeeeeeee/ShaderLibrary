# Blender ExportVAT

#### 介绍
Blender导出VAT的脚本

ExportVAT1.py的使用说明
 [点击这里](http://www.bilibili.com/read/cv9356097)

ExportVAT_Panel.py使用教程[点击这里](https://www.bilibili.com/video/BV125411J7UW)

VAT_Demo 色彩空间使用的是线性空间。
